<?php
     
     $nameServer = 'project-mysql';
     $userName = 'wordpress';
     $password = 'S0li@riu$954';
     $DBname = 'wordpress';
     
     printf($password);
     echo "<br>";

     $mysqli = new mysqli($nameServer, $userName, $password, $DBname);
 
    if ($mysqli -> connect_error) {
       printf("Соединение не удалось: %s\n", $mysqli -> connect_error);
    exit();
    };
?>
